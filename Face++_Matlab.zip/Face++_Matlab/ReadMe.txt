﻿==========================================================
    Face++ Research Toolkit - Matlab SDK      
    Copyright © 2013 Megvii, Inc. All Rights Reserved. 
==========================================================
Core Files:	
        facepp.m                : Face++ Detection/Landmark API SDK
        facepp_demo.m           : Demo Code	
	
==========================================================
How to Use:
        1. Register user on http://www.faceplusplus.com , and create an App on DevCenter, obtain API_KEY & API_SECRET
        2. Launch Matlab
        3. Open facepp_demo.m
        4. Replace the API_KEY & API_SECRET in line 7 & 8
        5. Run it :-)
